import SwiftUI

// Define the Card model
enum Rarity: String, CaseIterable {
    case common, rare, epic, legendary, mythical
}

struct Card: Identifiable {
    let id = UUID()
    let image: String
    let name: String
    let rarity: Rarity
    let sellValue: Double
}

// Define the CardDeck
struct CardDeck {
    private let allCards: [Card] = [
        Card(image: "light", name: "Light Yagami", rarity: .mythical, sellValue: 80.0),
        Card(image: "tatsumi", name: "Tatsumi", rarity: .rare, sellValue: 6.0),
        Card(image: "ui_goku", name: "UI Goku", rarity: .epic, sellValue: 15.0),
        Card(image: "madara", name: "Madara Uchiha", rarity: .legendary, sellValue: 30.0),
        Card(image: "goku_black", name: "Goku Black", rarity: .mythical, sellValue: 60.0),
        Card(image: "saitama", name: "Saitama", rarity: .common, sellValue: 2.5),
        Card(image: "inuyasha", name: "Inuyasha", rarity: .rare, sellValue: 7.0),
        Card(image: "shinji", name: "Shinji Ikari", rarity: .epic, sellValue: 18.0),
        Card(image: "kakashi", name: "Kakashi Hatake", rarity: .legendary, sellValue: 35.0),
        Card(image: "bulma", name: "Bulma", rarity: .mythical, sellValue: 65.0),
        Card(image: "natsu", name: "Natsu Dragneel", rarity: .common, sellValue: 3.0),
        Card(image: "erza", name: "Erza Scarlet", rarity: .rare, sellValue: 8.0),
        Card(image: "lucy", name: "Lucy Heartfilia", rarity: .epic, sellValue: 20.0),
        Card(image: "jellal", name: "Jellal Fernandes", rarity: .legendary, sellValue: 40.0),
        Card(image: "gray", name: "Gray Fullbuster", rarity: .mythical, sellValue: 70.0)
    ]
    
    func drawRandomCards(count: Int, rarityProbability: [Rarity: Double], specialMythical: Bool = false) -> [Card] {
        var availableCards = [Card]()
        for card in allCards {
            let probability = rarityProbability[card.rarity] ?? 0
            if Double.random(in: 0...1) <= probability {
                availableCards.append(card)
            }
        }

        // Add special mythical cards if it's a special pack
        if specialMythical {
            let mythicalCards = allCards.filter { $0.rarity == .mythical }
            if let mythicalCard = mythicalCards.randomElement(), Double.random(in: 0...1) <= 0.1 {
                availableCards.append(mythicalCard)
            }
        }

        return Array(availableCards.shuffled().prefix(count))
    }
}

// Define a custom ViewModifier
struct CardAnimationModifier: ViewModifier {
    let rotation: Double
    let scale: CGFloat
    let opacity: Double
    let shadowColor: Color?
    let shadowRadius: CGFloat
    let brightness: Double?

    init(rotation: Double, scale: CGFloat, opacity: Double = 1.0, shadowColor: Color? = nil, shadowRadius: CGFloat = 0, brightness: Double? = nil) {
        self.rotation = rotation
        self.scale = scale
        self.opacity = opacity
        self.shadowColor = shadowColor
        self.shadowRadius = shadowRadius
        self.brightness = brightness
    }
    
    func body(content: Content) -> some View {
        content
            .rotationEffect(.degrees(rotation))
            .scaleEffect(scale)
            .opacity(opacity)
            .shadow(color: shadowColor ?? .clear, radius: shadowRadius)
            .brightness(brightness ?? 0)
    }
}

// Define the CardFlashView
struct CardFlashView: View {
    let card: Card
    @Binding var isShowing: Bool

    var borderColor: Color {
        switch card.rarity {
        case .common:
            return .gray
        case .rare:
            return .blue
        case .epic:
            return .purple
        case .legendary:
            return .orange
        case .mythical:
            return .red
        }
    }

    var body: some View {
        ZStack {
            if isShowing {
                VStack {
                    Image(card.image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 200)
                        .border(borderColor, width: 4)
                        .modifier(getAnimation(for: card.rarity))
                    Text(card.name)
                        .font(.custom("Comic Sans MS", size: 18)) // Fun font
                        .foregroundColor(.black)
                    Text(card.rarity.rawValue.capitalized)
                        .font(.custom("Comic Sans MS", size: 14)) // Fun font
                        .foregroundColor(borderColor)
                }
                .opacity(isShowing ? 1.0 : 0.0)
                .scaleEffect(isShowing ? 1.0 : 0.5)
                .animation(.easeInOut(duration: 0.5), value: isShowing)
            }
        }
    }

    private func getAnimation(for rarity: Rarity) -> some ViewModifier {
        switch rarity {
        case .common:
            return CardAnimationModifier(rotation: 0, scale: 1.0)
        case .rare:
            return CardAnimationModifier(rotation: 10, scale: 1.1)
        case .epic:
            return CardAnimationModifier(rotation: 20, scale: 1.2, opacity: 0.8)
        case .legendary:
            return CardAnimationModifier(rotation: 30, scale: 1.3, opacity: 1.0, shadowColor: .yellow, shadowRadius: 10)
        case .mythical:
            return CardAnimationModifier(rotation: 40, scale: 1.4, opacity: 1.0, shadowColor: .red, shadowRadius: 15, brightness: 0.5)
        }
    }
}

// Define the InventoryView
struct InventoryView: View {
    @Binding var inventory: [Card]
    @Binding var money: Double

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 20) {
                ForEach(inventory) { card in
                    VStack {
                        Image(card.image)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 150)
                            .border(borderColor(for: card.rarity), width: 2)
                            .padding()
                        Text(card.name)
                            .font(.custom("Comic Sans MS", size: 16)) // Fun font
                        Text("Rarity: \(card.rarity.rawValue.capitalized)")
                            .font(.custom("Comic Sans MS", size: 14)) // Fun font
                        Text("Sell Value: $\(card.sellValue, specifier: "%.2f")")
                            .font(.custom("Comic Sans MS", size: 14)) // Fun font
                        Button(action: {
                            sellCard(card)
                        }) {
                            Text("Sell")
                                .font(.custom("Comic Sans MS", size: 16)) // Fun font
                                .foregroundColor(.red)
                        }
                    }
                    .padding()
                    .background(Color.white.opacity(0.8))
                    .cornerRadius(10)
                    .shadow(radius: 5)
                }
            }
            .padding()
        }
        .background(
            LinearGradient(gradient: Gradient(colors: [.pink, .purple]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)
        )
    }

    private func borderColor(for rarity: Rarity) -> Color {
        switch rarity {
        case .common:
            return .gray
        case .rare:
            return .blue
        case .epic:
            return .purple
        case .legendary:
            return .orange
        case .mythical:
            return .red
        }
    }

    private func sellCard(_ card: Card) {
        if let index = inventory.firstIndex(where: { $0.id == card.id }) {
            inventory.remove(at: index)
            money += card.sellValue
        }
    }
}

// Define the ContentView
struct ContentView: View {
    @State private var drawnCards: [Card] = []
    @State private var currentCardIndex: Int = 0
    @State private var isShowingCard: Bool = false
    @State private var money: Double = 100.0
    @State private var inventory: [Card] = []
    @State private var currentPage: Page = .home

    enum PackType {
        case basic, premium, special
    }

    enum Page {
        case home, inventory
    }

    var body: some View {
        TabView(selection: $currentPage) {
            VStack {
                Text("Money: $\(money, specifier: "%.2f")")
                    .font(.custom("Comic Sans MS", size: 20)) // Fun font
                    .padding()

                Button("Buy Basic Pack - $10") {
                    buyPack(type: .basic)
                }
                .padding()
                .disabled(money < 10)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .shadow(radius: 5)

                Button("Buy Premium Pack - $25") {
                    buyPack(type: .premium)
                }
                .padding()
                .disabled(money < 25)
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(10)
                .shadow(radius: 5)

                Button("Buy Special Pack - $50") {
                    buyPack(type: .special)
                }
                .padding()
                .disabled(money < 50)
                .background(Color.purple)
                .foregroundColor(.white)
                .cornerRadius(10)
                .shadow(radius: 5)

                if !drawnCards.isEmpty {
                    ZStack {
                        ForEach(0..<drawnCards.count, id: \.self) { index in
                            CardFlashView(card: drawnCards[index], isShowing: $isShowingCard)
                                .opacity(index == currentCardIndex ? 1.0 : 0.0)
                                .scaleEffect(index == currentCardIndex ? 1.0 : 0.5)
                                .animation(.easeInOut(duration: 0.5), value: currentCardIndex)
                        }
                    }
                    .padding()

                    HStack {
                        Button("Previous") {
                            if currentCardIndex > 0 {
                                currentCardIndex -= 1
                            }
                        }
                        .disabled(currentCardIndex == 0)
                        .font(.custom("Comic Sans MS", size: 16)) // Fun font

                        Button("Next") {
                            if currentCardIndex < drawnCards.count - 1 {
                                currentCardIndex += 1
                            }
                        }
                        .disabled(currentCardIndex == drawnCards.count - 1)
                        .font(.custom("Comic Sans MS", size: 16)) // Fun font
                    }
                    .padding()
                }
            }
            .tabItem {
                Label("Home", systemImage: "house")
            }
            .tag(Page.home)

            InventoryView(inventory: $inventory, money: $money)
                .tabItem {
                    Label("Inventory", systemImage: "folder")
                }
                .tag(Page.inventory)
        }
        .background(
            LinearGradient(gradient: Gradient(colors: [.yellow, .orange]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)
        )
    }

    private func buyPack(type: PackType) {
        let cardDeck = CardDeck()
        let rarityProbability: [Rarity: Double]

        switch type {
        case .basic:
            rarityProbability = [.common: 0.7, .rare: 0.2, .epic: 0.1]
            money -= 10
        case .premium:
            rarityProbability = [.common: 0.5, .rare: 0.3, .epic: 0.15, .legendary: 0.05]
            money -= 25
        case .special:
            rarityProbability = [.common: 0.4, .rare: 0.3, .epic: 0.2, .legendary: 0.09, .mythical: 0.01]
            money -= 50
        }

        let cards = cardDeck.drawRandomCards(count: 5, rarityProbability: rarityProbability, specialMythical: type == .special)
        drawnCards = cards
        inventory.append(contentsOf: cards)
        currentCardIndex = 0
        isShowingCard = true
    }
}

// Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
