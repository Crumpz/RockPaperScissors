//
//  Top10ProjectApp.swift
//  Top10Project
//
//  Created by Sudowe, Yuki - Student on 8/29/24.
//

import SwiftUI

@main
struct Top10ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
